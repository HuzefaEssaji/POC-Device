/*
 * ECG.h
 *
 *  Created on: Nov 30, 2022
 *      Author: acer
 */

#ifndef INC_ECG_REG_H_
#define INC_ECG_REG_H_



#endif /* INC_ECG_REG_H_ */

#define Set_PLL_CONFIGURATION_1      			(uint8_t)0x1
#define Set_PLL_CONFIGURATION_2      			(uint8_t)0x7f
#define Set_PLL_CONFIGURATION_4      			(uint8_t)0x1
#define Set_PLL_CONFIGURATION_5      			(uint8_t)0x10
#define Set_PLL_CONFIGURATION_6      			(uint8_t)0x20
#define Set_ECG_CONFIGURATION_1      			(uint8_t)0xa  //without enable
#define Set_ECG_CONFIGURATION_2      			(uint8_t)0x00
#define Set_ECG_CONFIGURATION_3      			(uint8_t)0x4
#define Set_ECG_CONFIGURATION_4      			(uint8_t)0x80
#define Set_ECG_LEAD_BIAS_CONFIGURATION_1       (uint8_t)0x00
#define Set_ECG_CAL_CONFIGURATION_3            	(uint8_t)0x00
#define Set_ECG_LEAD_DETECT_CONFIGURATION_1    	(uint8_t)0x07
#define Set_ECG_LEAD_DETECT_CONFIGURATION_2    	(uint8_t)0x60
#define Set_RLD_CONFIGUATION_1                 	(uint8_t)0xdf
#define Set_RLD_CONFIGUATION_2                 	(uint8_t)0x40

