/*
 * INC_MAX86178_ECG.h
 *
 *  Created on: Nov 30, 2022
 *      Author: acer
 */

#ifndef INC_INC_MAX86178_ECG_H_
#define INC_INC_MAX86178_ECG_H_



#endif /* INC_INC_MAX86178_ECG_H_ */


unsigned char * max_read_reg( unsigned char  reg_addr,uint8_t count);

void  max_write_reg(uint8_t reg_addr,uint8_t  write_val,uint8_t count);

void ECG_init();
