/*
 * INC_MAX86178_ECG.c
 *
 *  Created on: Nov 30, 2022
 *      Author: acer
 */

#include <ECG_REG.h>
#include "stm32f3xx_hal.h"
#include "86178_REG.h"
#include <stdlib.h>
#include <stdio.h>


unsigned char rx_global[18];    // rx buffer for burst read (20-> for additional dummy bytes in read command+reg addr)
								// same buffer is used in single word spi read
extern SPI_HandleTypeDef hspi3;

unsigned char * max_read_reg( unsigned char  reg_addr,uint8_t count)
{
	unsigned char tx[count+2];
	unsigned char rx[count+2];

	//read

	tx[0] = reg_addr;
	tx[1] = 0x80;
	tx[2] = 0xff;

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}

	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_RESET);
	HAL_SPI_TransmitReceive(&hspi3, tx, rx, (uint16_t)count+2, (uint32_t)1000);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_SET);


	for (int i = 2; i < count+2; i++)
	{
		rx_global[i-2] = rx[i];

	}
	return rx_global;

}
/*/////////////////////////////////////////////////////////////////////////////////////////////*/
void  max_write_reg(uint8_t reg_addr,uint8_t  write_val,uint8_t count)
{

	unsigned char tx[count+2];

	max_read_reg(reg_addr,count);  //dummy read

	//write
	tx[0] = reg_addr;
	tx[1] = 0x00;
	tx[2] = write_val;

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}


	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_RESET);
	HAL_SPI_Transmit(&hspi3, tx, (uint16_t)count+2, (uint32_t)1000);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_SET);
	tx[2] = 0xff;

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}

}

/*////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/


void ECG_init()
{
	//sample_rate at 512sps
	unsigned char pll_config[10]=
	{
			PLL_Configuration_6,			Set_PLL_CONFIGURATION_6,      //set reference clock   and clock frequency
			PLL_Configuration_2,  			Set_PLL_CONFIGURATION_2,      //set MDIV 						  //Set_PLL_Config2,
			PLL_Configuration_5,			Set_PLL_CONFIGURATION_5,	  //ecg NDIV
			PLL_Configuration_4,			Set_PLL_CONFIGURATION_4,	  //ecg FDIV
			PLL_Configuration_1,			Set_PLL_CONFIGURATION_1,	  //PLL enable
	};

	unsigned char ecg_config[26]=
	{
			ECG_Configuration_1,			Set_ECG_CONFIGURATION_1,      //ecg decimation rate
			ECG_Configuration_2,			Set_ECG_CONFIGURATION_2,		  //ecg PGA gain
			ECG_Configuration_2,			Set_ECG_CONFIGURATION_2 | 0x00,		//ecg INA RGE
			ECG_Configuration_2,			Set_ECG_CONFIGURATION_2 | 0x00,  //ecg INA gain
			ECG_Configuration_3,			Set_ECG_CONFIGURATION_3,      //ecg auto recovery
			ECG_Configuration_4,			Set_ECG_CONFIGURATION_4,		//ecg fast recovery
			ECG_Configuration_4,			Set_ECG_CONFIGURATION_4 | 0x3d,   //ecg fat  recovery threshold
			ECG_Lead_Bias_Configuration_1,	Set_ECG_LEAD_BIAS_CONFIGURATION_1, //enable ecg RBIASP
			ECG_Lead_Bias_Configuration_1,	Set_ECG_LEAD_BIAS_CONFIGURATION_1 | 0x00, //enable ecg RBIASN
			ECG_Configuration_3,			Set_ECG_CONFIGURATION_3 | 0x1,				//ecg mux select
			ECG_CAL_Configuration_3,		Set_ECG_CAL_CONFIGURATION_3,    //ecg open P
			ECG_CAL_Configuration_3,		Set_ECG_CAL_CONFIGURATION_3 | 0x00,    //ecg open N
			ECG_Configuration_1,			Set_ECG_CONFIGURATION_1 | 0x01      //ecg enable
	};

	unsigned char ecg_lead_off_detect_config[10]=
	{
			ECG_Lead_Detect_Configuration_1,	Set_ECG_LEAD_DETECT_CONFIGURATION_1,  //ecg loff frequency
			ECG_Lead_Detect_Configuration_2,	Set_ECG_LEAD_DETECT_CONFIGURATION_2,	//ecg loff imag
			ECG_Lead_Detect_Configuration_2,	Set_ECG_LEAD_DETECT_CONFIGURATION_2 | 0x02,	//ecg loff threshold
			ECG_Lead_Detect_Configuration_1,	Set_ECG_LEAD_DETECT_CONFIGURATION_1 | 0x08,	//ecg loff mode
			ECG_Lead_Detect_Configuration_1,	Set_ECG_LEAD_DETECT_CONFIGURATION_1 | 0x08 | 0x40, //enable ecg lead off detect
	};

	unsigned char rld_config[4]=
	{
			RLD_Configuration_2,		Set_RLD_CONFIGUATION_2,   //setting all the register at once
			RLD_Configuration_1,		Set_RLD_CONFIGUATION_1,   //setting all the register at once
	};
/////////////////// fifo and interrupt configuration
	unsigned char fifo_config[8]=
	{
			0x0d,0xfa,  			//fifo config --fifo a full
			0x13,0x01,				//interrupt 1 config
			0xc0,0x80,				//enable interrupt for fifo a full
			0x0e,0x18,				//fifo clear and fifo flushed
	};


	for(int i=0; i<10;i=i+2)
	{
		max_write_reg(pll_config[i],pll_config[i+1],1);
		HAL_Delay(1);
	}

	for(int i=0; i<26;i=i+2)
	{
		max_write_reg(ecg_config[i],ecg_config[i+1],1);
		HAL_Delay(1);
	}

	for(int i=0; i<10;i=i+2)
	{
		max_write_reg(ecg_lead_off_detect_config[i],ecg_lead_off_detect_config[i+1],1);
		HAL_Delay(1);
	}

	for(int i=0; i<4;i=i+2)
	{
		max_write_reg(rld_config[i],rld_config[i+1],1);
		HAL_Delay(1);
	}

	for(int i=0; i<8;i=i+2)
	{
		max_write_reg(fifo_config[i],fifo_config[i+1],1);
		HAL_Delay(1);
	}

}
