/*
 * INC_X86178.c
 *
 *  Created on: Sep 7, 2022
 *      Author: Huzefa Essaji
 */

//#include "INC_MAX86178.h"

#include "stm32f3xx_hal.h"
#include "cyprus.h"
#include "86178_REG.h"
#include <stdlib.h>
#include <stdio.h>
/*
unsigned char tx[3];
unsigned char rx[3];
unsigned char burst_rx[6];
 */

//unsigned char rec[8];
unsigned char rx_global[18];  // rx buffer for burst read (20-> for additional dummy bytes in read command+reg addr)
// same buffer is used in single word spi read
//extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart5;
extern int no_of_samples[1];
//unsigned char sample[9000];
extern int flag_afull;
extern SPI_HandleTypeDef hspi2;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
uint8_t * max_read_reg( unsigned char  reg_addr,uint8_t count)
{
	unsigned char tx[count+2];
	unsigned char rx[count+2];

	//read

	tx[0] = reg_addr;		//register address
	tx[1] = 0x80;         	//read command
	tx[2] = 0xff;			//dummy value

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}

	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_RESET);
	HAL_SPI_TransmitReceive(&hspi2, tx, rx, (uint16_t)count+2, (uint32_t)1000);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_SET);


	for (int i = 2; i < count+2; i++)
	{
		rx_global[i-2] = rx[i];

	}
	return rx_global;

}
/*/////////////////////////////////////////////////////////////////////////////////////////////*/
void  max_write_reg(uint8_t reg_addr,uint8_t  write_val,uint8_t count)
{

	unsigned char tx[count+2];



	//write
	tx[0] = reg_addr;			//register address
	tx[1] = 0x00;         		//write command
	tx[2] = write_val;			//write value

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}


	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_RESET);
	HAL_SPI_Transmit(&hspi2, tx, (uint16_t)count+2, (uint32_t)1000);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_1,GPIO_PIN_SET);
	tx[2] = 0xff;

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}
	max_read_reg(reg_addr,count);  //dummy read

}

/*////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/

uint32_t Combine_Sample_Bytes(uint32_t msb_sample,uint32_t mid_sample,uint32_t lsb_sample)
{

	uint32_t temp = 0;
	msb_sample =  0x0000000F & msb_sample ;
	msb_sample = msb_sample << 16;
	temp = temp | msb_sample;
	mid_sample = mid_sample<< 8;
	temp = temp | mid_sample;
	temp = temp | lsb_sample;

	return -1*temp;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void soft_reset()
{
	max_write_reg(0x18,0x00, 1);
	max_write_reg(0x11,0x01, 1);
	max_write_reg(0x18,0x01, 1);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void shutdown()
{
	max_write_reg(0x20,0x00, 1);
	max_write_reg(0x80,0x00, 1);
	max_write_reg(0x88,0x00, 1);
	max_write_reg(0xa0,0x00, 1);
	max_write_reg(0x18,0x00, 1);
	max_write_reg(0x11,0x02, 1);
}

void powerup()
{
	max_write_reg(0x11,0x00, 1);
	max_write_reg(0x20,0x00, 1);
	max_write_reg(0x80,0x00, 1);
	max_write_reg(0x88,0x00, 1);
	max_write_reg(0xa0,0x00, 1);
	max_write_reg(0x18,0x01, 1);
															// check if freuency and phase lock has occured
	while(1)
	{														//rxval to check pll lock value
		if(*(max_read_reg(0x02,1))==0x0A){
			break;
		}
	}
}
/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
void max_read_fifo()
{
	max_read_reg(0x00,1);
	HAL_UART_Transmit(&huart5, max_read_reg(0x0c,18), no_of_samples[0],10);
	flag_afull=0;
}
/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/

void ppg_init()

{
	unsigned char fr_clk_config[4]=
	{
			FR_Clock_Divider_MSB,			Set_FR_CLK_DIV_MSB,
			FR_Clock_Divider_LSB,			Set_FR_CLK_DIV_LSB
	};


	unsigned char ppg_config[28]=
	{
			PPG_Configuration_1,			Set_ppg_config1,
			PPG_Configuration_2,			Set_ppg_config2,
			PPG_Configuration_3,			Set_ppg_config3,
			PPG_Configuration_4,			Set_ppg_config4,
			Photodiode_Bias, 				Set_photodiode_bias,
			MEAS1_Selects,					Set_MEAS1_DRVA,
			MEAS1_Configuration_1,			0x58,//Set_MEAS1_FLTR2_SEL,
			MEAS1_Configuration_2,			0x33,//Set_MEAS1_PPG2_ADC_RGE,
			MEAS1_Configuration_3,			0x00,
			MEAS1_Configuration_4,			0x47,//Set_MEAS1_LED_SETLNG,
			MEAS1_Configuration_4,			0x0E,//Set_MEAS1_PD3_SEL,
			MEAS1_LEDA,						0x0F,//Set_MEAS1_DRVB_PA,//Set_MEAS1_DRVA_PA,
			MEAS1_LEDB,						0x00,
			0x0e,							0x18
	};

	///////////////////////////////////////////////////////////////////////////////////

	unsigned char reset_config[22]=

	{
			//0x11,0x00,

			0x20,0x00,
			0x80,0x00,
			0x88,0x00,
			0xa0,0x00,
			0x0e,0x18,

			0x1d,0x20,
			0x18,0x01,

			0x13,0x01,
			0xc0,0x80,

			0x0d,0xfa,

			0x0e,0x18
	};



	for(int i=0; i<22;i=i+2)
	{
		max_write_reg(reset_config[i],reset_config[i+1],1);
		//HAL_Delay(1);
	}

	for(int i=0; i<4;i=i+2)
	{

		max_write_reg(fr_clk_config[i],fr_clk_config[i+1],1);
		HAL_Delay(1);
	}

	/////////////////////////////////////////////////////////
	/// ppg sensor measurement select and corresponding sensor channel config
	for(int i=0; i<28;i=i+2)
	{
		max_write_reg(ppg_config[i],ppg_config[i+1],1);
		HAL_Delay(1);
	}

	//////////////////////////////////////////////////////////////
	// end ppg initialisation
	//////////////////////////////////////////////////////////////
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ECG_init()
{

///////////////////////////////////////////////////////////////////////////////////

	unsigned char reset_config[22]=

	{
			//0x11,0x00,

			0x20,0x00,
			0x80,0x00,
			0x88,0x00,
			0xa0,0x00,
			0x0e,0x18,

			0x1d,0x20,
			0x18,0x01,

			0x13,0x01,
			0xc0,0x80,

			0x0d,0xfa,

			0x0e,0x18
	};

	for(int i=0; i<22;i=i+2)
	{
			max_write_reg(reset_config[i],reset_config[i+1],1);
			//HAL_Delay(1);
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//sample_rate at 512sps
	unsigned char pll_config[10]=
	{
			PLL_Configuration_6,			Set_PLL_CONFIGURATION_6,      //set reference clock   and clock frequency
			PLL_Configuration_2,  			/*0xff,*/Set_PLL_CONFIGURATION_2,      //set MDIV 						  //Set_PLL_Config2,
			PLL_Configuration_5,			/*0x40,*/Set_PLL_CONFIGURATION_5,	  //ecg NDIV
			PLL_Configuration_4,			/*0x03,*/Set_PLL_CONFIGURATION_4,	  //ecg FDIV
			PLL_Configuration_1,			Set_PLL_CONFIGURATION_1	  //PLL enable
	};

	unsigned char ecg_config[26]=
	{
			ECG_Configuration_1,			/*0x08,*/Set_ECG_CONFIGURATION_1,      //ecg decimation rate
			ECG_Configuration_2,			/*0x01,*/Set_ECG_CONFIGURATION_2,		  //ecg PGA gain
			ECG_Configuration_2,			Set_ECG_CONFIGURATION_2 | 0x00,		//ecg INA RGE
			ECG_Configuration_2,			Set_ECG_CONFIGURATION_2 | 0x00,  //ecg INA gain
			ECG_Configuration_3,			/*0x01,*/Set_ECG_CONFIGURATION_3,      //ecg auto recovery
			ECG_Configuration_4,			/*0x3f,*/Set_ECG_CONFIGURATION_4,		//ecg fast recovery
			ECG_Configuration_4,			Set_ECG_CONFIGURATION_4 | 0x3d,   //ecg fast  recovery threshold
			ECG_Lead_Bias_Configuration_1,	Set_ECG_LEAD_BIAS_CONFIGURATION_1, //enable ecg RBIASP
			ECG_Lead_Bias_Configuration_1,	Set_ECG_LEAD_BIAS_CONFIGURATION_1 | 0x04, //enable ecg RBIASN
			ECG_Configuration_3,			Set_ECG_CONFIGURATION_3 | 0x1,				//ecg mux select
			ECG_CAL_Configuration_3,		Set_ECG_CAL_CONFIGURATION_3,    //ecg open P
			ECG_CAL_Configuration_3,		Set_ECG_CAL_CONFIGURATION_3 | 0x00,    //ecg open N
			ECG_Configuration_1,			Set_ECG_CONFIGURATION_1 | 0x01      //ecg enable
	};

	unsigned char ecg_lead_off_detect_config[10]=
	{
			ECG_Lead_Detect_Configuration_1,	Set_ECG_LEAD_DETECT_CONFIGURATION_1,  //ecg loff frequency
			ECG_Lead_Detect_Configuration_2,	Set_ECG_LEAD_DETECT_CONFIGURATION_2,	//ecg loff imag
			ECG_Lead_Detect_Configuration_2,	Set_ECG_LEAD_DETECT_CONFIGURATION_2 | 0x02,	//ecg loff threshold
			ECG_Lead_Detect_Configuration_1,	Set_ECG_LEAD_DETECT_CONFIGURATION_1 | 0x08,	//ecg loff mode
			ECG_Lead_Detect_Configuration_1,	Set_ECG_LEAD_DETECT_CONFIGURATION_1 | 0x08 | 0x40, //enable ecg lead off detect
	};

	unsigned char rld_config[6]=
	{
			RLD_Configuration_2,		Set_RLD_CONFIGUATION_2,   //setting all the register at once
			RLD_Configuration_1,		/*0xce,*/Set_RLD_CONFIGUATION_1,   //setting all the register at once
			0x0e,0x18
	};
/////////////////// fifo and interrupt configuration
//	unsigned char fifo_config[8]=
//	{
//			0x0d,0xfa,  			//fifo config --fifo a full
//			0x13,0x01,				//interrupt 1 config
//			0xc0,0x80,				//enable interrupt for fifo a full
//			0x0e,0x18,				//fifo clear and fifo flushed
//	};


	for(int i=0; i<10;i=i+2)
	{
		max_write_reg(pll_config[i],pll_config[i+1],1);
//		HAL_Delay(1);
	}

	for(int i=0; i<26;i=i+2)
	{
		max_write_reg(ecg_config[i],ecg_config[i+1],1);
//		HAL_Delay(1);
	}

	for(int i=0; i<10;i=i+2)
	{
		max_write_reg(ecg_lead_off_detect_config[i],ecg_lead_off_detect_config[i+1],1);
//		HAL_Delay(1);
	}

	for(int i=0; i<6;i=i+2)
	{
		max_write_reg(rld_config[i],rld_config[i+1],1);
//		HAL_Delay(1);
	}

//	for(int i=0; i<8;i=i+2)
//	{
//		max_write_reg(fifo_config[i],fifo_config[i+1],1);
//		HAL_Delay(1);
//	}



}
