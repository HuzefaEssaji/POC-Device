/*
 * INC_X86178.c
 *
 *  Created on: Sep 7, 2022
 *      Author: Huzefa Essaji
 */

//#include "INC_MAX86178.h"

#include "stm32f3xx_hal.h"
#include "cyprus.h"
#include "86178_REG.h"
#include <stdlib.h>
#include <stdio.h>
/*
unsigned char tx[3];
unsigned char rx[3];
unsigned char burst_rx[6];
 */

//unsigned char rec[8];
unsigned char rx_global[20];  // rx buffer for burst read (20-> for additional dummy bytes in read command+reg addr)
// same buffer is used in single word spi read
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;

//unsigned char sample[9000];

extern SPI_HandleTypeDef hspi3;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
unsigned char * max_read_reg( unsigned char  reg_addr,uint8_t count)
{
	unsigned char tx[count+2];
	unsigned char rx[count+2];

	//read

	tx[0] = reg_addr;
	tx[1] = 0x80;
	tx[2] = 0xff;

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}

	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_RESET);
	HAL_SPI_TransmitReceive(&hspi3, tx, rx, (uint16_t)count+2, (uint32_t)1000);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_SET);


	for (int i = 0; i < count+2; i++)
	{
		rx_global[i] = rx[i];

	}
	return rx_global;

}
/*/////////////////////////////////////////////////////////////////////////////////////////////*/
void  max_write_reg(uint8_t reg_addr,uint8_t  write_val,uint8_t count)
{

	unsigned char tx[count+2];

	max_read_reg(reg_addr,count);  //dummy read

	//write
	tx[0] = reg_addr;
	tx[1] = 0x00;
	tx[2] = write_val;

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}


	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_RESET);
	HAL_SPI_Transmit(&hspi3, tx, (uint16_t)count+2, (uint32_t)1000);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_3,GPIO_PIN_SET);
	tx[2] = 0xff;

	for(int i=3;i<count+2;i++)
	{
		tx[i]=0xff;
	}

}

/*////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/

uint32_t Combine_Sample_Bytes(uint32_t msb_sample,uint32_t mid_sample,uint32_t lsb_sample)
{

	uint32_t temp = 0;
	msb_sample =  0x0000000F & msb_sample ;
	msb_sample = msb_sample << 16;
	temp = temp | msb_sample;
	mid_sample = mid_sample<< 8;
	temp = temp | mid_sample;
	temp = temp | lsb_sample;

	return -1*temp;
}



/*///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/

void ppg_init()

{


	unsigned char pll_config[10]=
	{
			PLL_Configuration_6,			Set_PLL_Config6,

			0x18,							0x1, ////pll config,                /////////////////////

			PLL_Configuration_2,  			0x56     ///////Set_PLL_Config2,


	};

	unsigned char fr_clk_config[4]=
	{

			FR_Clock_Divider_MSB,			Set_FR_CLK_DIV_MSB,
			FR_Clock_Divider_LSB,			Set_FR_CLK_DIV_LSB
	};


	unsigned char ppg_config[28]=
	{
			PPG_Configuration_1,			Set_ppg_config1,
			PPG_Configuration_2,			Set_ppg_config2,
			PPG_Configuration_3,			Set_ppg_config3,
			PPG_Configuration_4,			Set_ppg_config4,
			Photodiode_Bias, 				Set_photodiode_bias,
			MEAS1_Selects,					Set_MEAS1_DRVA,
			MEAS1_Configuration_1,			0x58,//Set_MEAS1_FLTR2_SEL,
			MEAS1_Configuration_2,			0x33,//Set_MEAS1_PPG2_ADC_RGE,
			MEAS1_Configuration_3,			0x00,
			MEAS1_Configuration_4,			0x47,//Set_MEAS1_LED_SETLNG,
			MEAS1_Configuration_4,			0x0E,//Set_MEAS1_PD3_SEL,
			MEAS1_LEDA,						0x0F,//Set_MEAS1_DRVB_PA,//Set_MEAS1_DRVA_PA,
			MEAS1_LEDB,						0x00,




	};



	unsigned char misc_config[2]=

	{

			//	0x0d,							0xfa,

			//	Pin_Functional_Configuration,  	Set_Pin_Functional_Configuration,


			//	0xc0,							0x80,

			//0xc5,							0x00//

			//	0x0e,							0x14,




	};




	///////////////////////////////////////////////////////////////////////////////////

	unsigned char reset_config[22]=

	{

			//0x11,0x00,

			0x20,0x00,
			0x80,0x00,
			0x88,0x00,
			0xa0,0x00,
			0x0e,0x18,

			0x1d,0x20,
			0x18,0x01,

			0x13,0x01,
			0xc0,0x80,

			0x0d,0xfa,

			0x0e,0x18






	};



	//////////////////////////////////////////////////////////////
	//pll config routine


	//	for(int i=0; i<10;i=i+2)
	//		{
	//			max_write_reg(pll_config[i],pll_config[i+1],1);
	//			HAL_Delay(1);
	//		}

	for(int i=0; i<22;i=i+2)
	{
		max_write_reg(reset_config[i],reset_config[i+1],1);
		//HAL_Delay(1);
	}

	//		HAL_Delay(10);


	//////////////////////////////////////////////////////////////



	// check if freuency and phase lock has occured
	while(1){
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET);

		unsigned char rxval = *(max_read_reg(0x02,1)+2);   //rxval to check pll lock value
		if(rxval==0x0A){
			HAL_Delay(1000);
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_RESET);
			break;
		}


	}




	//////////////////////////////////////////////////////////////
	/////frame rateconfig routine
	for(int i=0; i<4;i=i+2)
	{

		max_write_reg(fr_clk_config[i],fr_clk_config[i+1],1);
		HAL_Delay(1);
	}

	// check for valid ppg frame rate
	while(1){

		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_SET);

		unsigned char rxval = *(max_read_reg(0x01,1)+2);   //rxval to check frame rate validity
		if(rxval==0x80){

			continue;
		}
		else{
			HAL_Delay(1000);
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET);
			break;
		}
	}
	//////////////////////////////////////////////////////////////////////
	// interrupt enable, fifo threshold and other system config routine

//	for(int i=0; i<2;i=i+2)
//	{
//		max_write_reg(misc_config[i],misc_config[i+1],1);
//		HAL_Delay(1);
//	}

	/////////////////////////////////////////////////////////
	/// ppg sensor measurement select and corresponding sensor channel config
	for(int i=0; i<28;i=i+2)
	{
		max_write_reg(ppg_config[i],ppg_config[i+1],1);
		HAL_Delay(1);
	}



	//////////////////////////////////////////////////////////////

	// check whether fifo data counter has incremented
	while(1){

		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET);

		unsigned char rxval = *(max_read_reg(0x0b,1)+2);   //rxval to check fifo data counter status
		if(rxval==0x00){

			continue;
		}
		else{
			HAL_Delay(1000);
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_RESET);
			break;
		}
	}





	// end ppg initialisation

	///////////////////////////////////////////////////////////////






}
